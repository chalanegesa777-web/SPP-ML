from flask import Flask, render_template, request, jsonify, send_file
import joblib
import numpy as np
import pandas as pd
import os
import sys
import subprocess
import threading
import io
import json

# Import sklearn modules for fallback training
try:
    from sklearn.linear_model import LinearRegression
    from sklearn.preprocessing import StandardScaler, LabelEncoder
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# Simple numpy-based linear regression for fallback
class SimpleLinearRegression:
    def __init__(self):
        self.weights = None
        self.bias = None

    def fit(self, X, y):
        # Add bias term
        X_b = np.c_[np.ones((X.shape[0], 1)), X]
        # Normal equation: w = (X^T * X)^(-1) * X^T * y
        try:
            self.weights = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)
            self.bias = self.weights[0]
            self.weights = self.weights[1:]
        except np.linalg.LinAlgError:
            # If singular matrix, use pseudoinverse
            self.weights = np.linalg.pinv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)
            self.bias = self.weights[0]
            self.weights = self.weights[1:]

    def predict(self, X):
        return X.dot(self.weights) + self.bias

# Simple standard scaler
class SimpleStandardScaler:
    def __init__(self):
        self.mean_ = None
        self.scale_ = None

    def fit_transform(self, X):
        self.mean_ = np.mean(X, axis=0)
        self.scale_ = np.std(X, axis=0)
        # Avoid division by zero
        self.scale_[self.scale_ == 0] = 1
        return (X - self.mean_) / self.scale_

    def transform(self, X):
        return (X - self.mean_) / self.scale_

# Simple label encoder
class SimpleLabelEncoder:
    def __init__(self):
        self.classes_ = None
        self.class_to_index_ = {}

    def fit_transform(self, y):
        # Handle NaN values by filtering them out for unique values
        y_clean = y.dropna() if hasattr(y, 'dropna') else y
        self.classes_ = np.unique(y_clean)
        self.class_to_index_ = {cls: idx for idx, cls in enumerate(self.classes_)}

        # Transform values, handling NaN
        result = []
        for val in y:
            if pd.isna(val):
                result.append(-1)  # Use -1 for NaN values
            else:
                result.append(self.class_to_index_.get(val, -1))
        return np.array(result)

    def transform(self, y):
        result = []
        for val in y:
            if pd.isna(val):
                result.append(-1)
            else:
                result.append(self.class_to_index_.get(val, -1))
        return np.array(result)


# Add parent directory to path to load models
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

app = Flask(__name__)

# Load models and preprocessors
model = None
scaler = None
label_encoders = None
feature_cols = None

MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models')
MODEL_PATH = os.path.join(MODEL_DIR, 'performance_model.pkl')
SCALER_PATH = os.path.join(MODEL_DIR, 'scaler.pkl')
ENCODERS_PATH = os.path.join(MODEL_DIR, 'label_encoders.pkl')
FEATURES_PATH = os.path.join(MODEL_DIR, 'feature_cols.pkl')


def load_pretrained_models():
    global model, scaler, label_encoders, feature_cols
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    label_encoders = joblib.load(ENCODERS_PATH)
    feature_cols = joblib.load(FEATURES_PATH)


try:
    load_pretrained_models()
    print(" Models loaded successfully!")
except Exception as e:
    print(f" Warning: {e}")
    print("Please run train_model.py first!")
    # Set defaults if loading fails
    feature_cols = ['study_hours_per_day', 'previous_score', 'attendance_percentage',
                    'sleep_hours_per_day', 'extracurricular_hours', 'family_income_level',
                    'parental_education', 'internet_access', 'past_failures']
    model = None
    scaler = None
    label_encoders = None


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        if model is None or scaler is None or label_encoders is None or feature_cols is None:
            return jsonify({'error': 'Models not loaded. Please train the model first.'}), 500
        
        # Get data from form
        input_data = []
        
        for col in feature_cols:
            value = request.form.get(col)
            
            if col in label_encoders:
                # Encode categorical values
                value = label_encoders[col].transform([value])[0]
            else:
                value = float(value)
            
            input_data.append(value)
        
        # Scale and predict
        input_scaled = scaler.transform([input_data])
        prediction = model.predict(input_scaled)[0]
        prediction = max(0, min(100, prediction))
        
        # Determine grade and advice
        if prediction >= 90:
            grade = 'A+'
            color = '#27ae60'
            advice = "Outstanding! Exceptional performance! You're at the top of your class!"
            icon = "🌟"
        elif prediction >= 85:
            grade = 'A'
            color = '#2ecc71'
            advice = "Excellent! Superior performance! Keep up the fantastic work!"
            icon = "🏆"
        elif prediction >= 80:
            grade = 'A-'
            color = '#27ae60'
            advice = "Very good! Strong performance! You're doing great!"
            icon = "👍"
        elif prediction >= 75:
            grade = 'B+'
            color = '#3498db'
            advice = "Good job! Solid performance. Aim for that A next time!"
            icon = "👏"
        elif prediction >= 70:
            grade = 'B'
            color = '#2980b9'
            advice = "Good work! You're on track. More effort could get you higher!"
            icon = "📈"
        elif prediction >= 65:
            grade = 'B-'
            color = '#3498db'
            advice = "Decent score. Focus on improvement to reach the next level!"
            icon = "📖"
        elif prediction >= 60:
            grade = 'C+'
            color = '#f39c12'
            advice = "Fair performance. More dedication and practice needed!"
            icon = "⚠️"
        elif prediction >= 55:
            grade = 'C'
            color = '#e67e22'
            advice = "Average performance. Consider increasing study time!"
            icon = "📚"
        elif prediction >= 50:
            grade = 'C-'
            color = '#f39c12'
            advice = "Below average. Significant improvement required!"
            icon = "🔄"
        elif prediction >= 45:
            grade = 'D'
            color = '#e74c3c'
            advice = "Poor performance. Seek help and create a study plan!"
            icon = "🎯"
        else:
            grade = 'F'
            color = '#c0392b'
            advice = "Failing grade. Don't give up! Get tutoring and study harder."
            icon = "💪"
        
        return render_template('result.html', 
                             prediction=round(prediction, 1),
                             grade=grade,
                             advice=advice,
                             color=color,
                             icon=icon)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """REST API endpoint for predictions"""
    try:
        if model is None or scaler is None or label_encoders is None or feature_cols is None:
            return jsonify({'success': False, 'error': 'Models not loaded. Please train the model first.'}), 500

        data = request.json
        input_data = []
        
        for col in feature_cols:
            value = data.get(col)
            if col in label_encoders:
                value = label_encoders[col].transform([value])[0]
            else:
                value = float(value)
            input_data.append(value)
        
        input_scaled = scaler.transform([input_data])
        prediction = model.predict(input_scaled)[0]
        prediction = max(0, min(100, prediction))
        
        return jsonify({
            'success': True,
            'predicted_score': round(prediction, 2),
            'grade': 'A+' if prediction >= 90 else 'A' if prediction >= 85 else 'A-' if prediction >= 80 else 'B+' if prediction >= 75 else 'B' if prediction >= 70 else 'B-' if prediction >= 65 else 'C+' if prediction >= 60 else 'C' if prediction >= 55 else 'C-' if prediction >= 50 else 'D' if prediction >= 45 else 'F'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/retrain', methods=['POST'])
def api_retrain():
    """Retrain the model using current dataset and reload artifacts"""
    global model, scaler, label_encoders, feature_cols
    try:
        # Use current Python executable
        python_exe = sys.executable
        script_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src', 'train_model.py')

        # Run training script with current Python
        result = subprocess.run([python_exe, script_path],
                              capture_output=True, text=True, cwd=os.path.dirname(script_path))

        if result.returncode != 0:
            # If training fails, provide a fallback that doesn't require sklearn
            return _fallback_retrain()

        # Reload models after successful training
        load_pretrained_models()
        return jsonify({'success': True, 'message': 'Model retrained and reloaded successfully.'})
    except Exception as e:
        # Try fallback retraining
        try:
            return _fallback_retrain()
        except Exception as fallback_error:
            return jsonify({'success': False, 'error': f'Both training methods failed: {str(e)}, fallback: {str(fallback_error)}'}), 500


def _fallback_retrain():
    """Fallback retraining using numpy-only implementations"""
    global model, scaler, label_encoders, feature_cols

    try:
        # Load existing data and create a simple model
        data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'student_data.csv')
        df = pd.read_csv(data_path)

        print(f"Loaded {len(df)} records from {data_path}")
        print(f"Columns: {df.columns.tolist()}")

        # Check for required columns (handle both uppercase and lowercase)
        required_cols = ['study_hours_per_day', 'previous_score', 'attendance_percentage',
                        'sleep_hours_per_day', 'extracurricular_hours', 'family_income_level',
                        'parental_education', 'internet_access', 'past_failures', 'final_score']

        # Map uppercase column names to lowercase if needed
        column_mapping = {}
        for col in required_cols:
            if col.upper() in df.columns:
                column_mapping[col] = col.upper()
            elif col in df.columns:
                column_mapping[col] = col

        missing_cols = [col for col in required_cols if col not in column_mapping]
        if missing_cols:
            raise Exception(f"Missing required columns: {missing_cols}")

        # Rename columns to lowercase for consistency
        df = df.rename(columns={v: k for k, v in column_mapping.items()})

        # Prepare data using simple encoders
        categorical_cols = ['family_income_level', 'parental_education', 'internet_access']
        label_encoders = {}

        for col in categorical_cols:
            try:
                le = SimpleLabelEncoder()
                df[col] = le.fit_transform(df[col])
                label_encoders[col] = le
                print(f"Encoded {col}: {len(le.classes_)} unique values")
            except Exception as e:
                raise Exception(f"Failed to encode column {col}: {str(e)}")

        feature_cols = ['study_hours_per_day', 'previous_score', 'attendance_percentage',
                       'sleep_hours_per_day', 'extracurricular_hours', 'family_income_level',
                       'parental_education', 'internet_access', 'past_failures']

        # Check for NaN values
        nan_counts = df[feature_cols + ['final_score']].isna().sum()
        if nan_counts.sum() > 0:
            print(f"Warning: Found NaN values: {nan_counts[nan_counts > 0].to_dict()}")
            # Fill NaN values with mean for numerical columns
            for col in feature_cols:
                if df[col].isna().sum() > 0:
                    if col in categorical_cols:
                        # For categorical, fill with most frequent
                        df[col] = df[col].fillna(df[col].mode().iloc[0])
                    else:
                        # For numerical, fill with mean
                        df[col] = df[col].fillna(df[col].mean())

        X = df[feature_cols].values
        y = df['final_score'].values

        print(f"Feature matrix shape: {X.shape}")
        print(f"Target vector shape: {y.shape}")

        # Scale features using simple scaler
        scaler = SimpleStandardScaler()
        X_scaled = scaler.fit_transform(X)

        # Train simple linear model
        model = SimpleLinearRegression()
        model.fit(X_scaled, y)

        # Save models
        os.makedirs(MODEL_DIR, exist_ok=True)
        joblib.dump(model, MODEL_PATH)
        joblib.dump(scaler, SCALER_PATH)
        joblib.dump(label_encoders, ENCODERS_PATH)
        joblib.dump(feature_cols, FEATURES_PATH)

        return jsonify({'success': True, 'message': 'Model retrained using numpy-based fallback (Linear Regression).'})

    except Exception as e:
        print(f"Fallback retrain error: {str(e)}")
        import traceback
        traceback.print_exc()
        raise Exception(f'Fallback retraining failed: {str(e)}')

@app.route('/api/analytics')
def get_analytics():
    """Get analytics data for charts"""
    try:
        data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'student_data.csv')
        df = pd.read_csv(data_path)

        # Score distribution
        score_distribution = []
        score_bins_labels = []
        for i in range(0, 100, 10):
            count = len(df[(df['FINAL_SCORE'] >= i) & (df['FINAL_SCORE'] < i+10)])
            score_distribution.append(count)
            score_bins_labels.append(f'{i}-{i+9}')

        # Grade distribution - handle extended grades
        grade_mapping = {
            'A+': 'A', 'A': 'A', 'A-': 'A',
            'B+': 'B', 'B': 'B', 'B-': 'B',
            'C+': 'C', 'C': 'C', 'C-': 'C',
            'D': 'D', 'F': 'F'
        }
        df['SIMPLE_GRADE'] = df['GRADE'].map(grade_mapping)
        grade_labels = ['A', 'B', 'C', 'D', 'F']
        grade_distribution = [len(df[df['SIMPLE_GRADE'] == g]) for g in grade_labels]

        # Feature importance (from model if available)
        if hasattr(model, 'feature_importances_'):
            feature_importance = model.feature_importances_.tolist()
        else:
            # Mock data for non-tree models
            feature_importance = [0.25, 0.35, 0.20, 0.08, 0.03, 0.04, 0.03, 0.01, 0.01]

        feature_names = ['Study Hours', 'Previous Score', 'Attendance', 'Sleep Hours',
                        'Extracurricular', 'Income', 'Parent Education', 'Internet', 'Past Failures']

        return jsonify({
            'score_bins': score_bins_labels,
            'score_distribution': score_distribution,
            'grade_labels': grade_labels,
            'grade_distribution': grade_distribution,
            'feature_names': feature_names,
            'feature_importance': feature_importance
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/feature-analysis')
def feature_analysis():
    """Get feature vs score analysis"""
    try:
        feature_param = request.args.get('feature', 'study_hours_per_day')

        # Map lowercase feature names to uppercase column names
        feature_mapping = {
            'study_hours_per_day': 'STUDY_HOURS_PER_DAY',
            'previous_score': 'PREVIOUS_SCORE',
            'attendance_percentage': 'ATTENDANCE_PERCENTAGE',
            'sleep_hours_per_day': 'SLEEP_HOURS_PER_DAY',
            'extracurricular_hours': 'EXTRACURRICULAR_HOURS'
        }

        feature = feature_mapping.get(feature_param, 'STUDY_HOURS_PER_DAY')
        data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'student_data.csv')
        df = pd.read_csv(data_path)

        # Get points for scatter plot
        points = []
        sample_df = df[[feature, 'FINAL_SCORE']].dropna().head(100)
        for idx, row in sample_df.iterrows():
            points.append({
                'x': float(row[feature]),
                'y': float(row['FINAL_SCORE'])
            })

        # Calculate correlation matrix
        numerical_cols = ['STUDY_HOURS_PER_DAY', 'PREVIOUS_SCORE', 'ATTENDANCE_PERCENTAGE',
                         'SLEEP_HOURS_PER_DAY', 'EXTRACURRICULAR_HOURS', 'PAST_FAILURES', 'FINAL_SCORE']

        # Filter only existing columns
        existing_cols = [col for col in numerical_cols if col in df.columns]
        correlation_matrix = df[existing_cols].corr()
        correlation = correlation_matrix.values.tolist()

        return jsonify({
            'points': points,
            'correlation': correlation,
            'features': existing_cols
        })
    except Exception as e:
        return jsonify({'error': str(e), 'points': [], 'correlation': []}), 400

@app.route('/api/stats')
def get_stats():
    """Get dashboard statistics"""
    try:
        data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'student_data.csv')
        df = pd.read_csv(data_path)
        
        stats = {
            'total_students': len(df),
            'average_score': round(df['FINAL_SCORE'].mean(), 2),
            'passing_rate': round(len(df[df['FINAL_SCORE'] >= 60]) / len(df) * 100, 2),
            'excellent_rate': round(len(df[df['FINAL_SCORE'] >= 90]) / len(df) * 100, 2)
        }
        
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/export/<format>')
def export_data(format):
    """Export student data in specified format"""
    try:
        data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'student_data.csv')
        df = pd.read_csv(data_path)

        if format.lower() == 'csv':
            # Export as CSV
            output = io.StringIO()
            df.to_csv(output, index=False)
            output.seek(0)
            return send_file(
                io.BytesIO(output.getvalue().encode('utf-8')),
                mimetype='text/csv',
                as_attachment=True,
                download_name='student_performance_data.csv'
            )

        elif format.lower() == 'json':
            # Export as JSON
            return send_file(
                io.BytesIO(json.dumps(df.to_dict('records'), indent=2).encode('utf-8')),
                mimetype='application/json',
                as_attachment=True,
                download_name='student_performance_data.json'
            )

        elif format.lower() == 'pdf':
            # Export as simple text-based PDF (without reportlab)
            pdf_content = f"""Student Performance Data Report
Generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}

Summary Statistics:
- Total Students: {len(df)}
- Average Score: {df['final_score'].mean():.2f}
- Passing Rate: {len(df[df['final_score'] >= 60]) / len(df) * 100:.1f}%
- Excellent Rate: {len(df[df['final_score'] >= 90]) / len(df) * 100:.1f}%

Data Preview (first 20 rows):
{df.head(20).to_string(index=False)}

Note: This is a simplified text export. For full PDF formatting, install reportlab library.
"""

            return send_file(
                io.BytesIO(pdf_content.encode('utf-8')),
                mimetype='text/plain',
                as_attachment=True,
                download_name='student_performance_report.txt'
            )

        else:
            return jsonify({'error': f'Unsupported format: {format}'}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)