// Global variables
let currentPage = 'home';
let scoreChart, gradeChart, featureChart, analyticsChart;
let refreshInterval = null;

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    loadCharts();
    setupNavigation();
    setupFormHandlers();
    loadSettings();
    
    // Auto-refresh if enabled
    const interval = localStorage.getItem('refreshInterval') || '0';
    if (interval !== '0') {
        startAutoRefresh(parseInt(interval));
    }
});

// Update date and time
function updateDateTime() {
    const now = new Date();
    const dateTimeStr = now.toLocaleString();
    const element = document.getElementById('currentDateTime');
    if (element) element.textContent = dateTimeStr;
}

// Navigation
function setupNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            switchPage(page);
        });
    });
}

function switchPage(page) {
    currentPage = page;
    
    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });
    
    // Update page visibility
    document.querySelectorAll('.page').forEach(pageEl => {
        pageEl.classList.remove('active');
    });
    document.getElementById(`${page}-page`).classList.add('active');
    document.body.classList.remove('page-home', 'page-prediction', 'page-analytics', 'page-settings');
    document.body.classList.add(`page-${page}`);
    
    // Update header title
    const titles = {
        home: { title: 'Dashboard Overview', subtitle: 'Welcome to Student Performance ML Dashboard' },
        prediction: { title: 'Performance Prediction', subtitle: 'Get AI-powered student performance predictions' },
        analytics: { title: 'Analytics Dashboard', subtitle: 'Deep dive into performance analytics' },
        settings: { title: 'Settings', subtitle: 'Configure your dashboard preferences' }
    };
    
    document.getElementById('page-title').textContent = titles[page].title;
    document.getElementById('page-subtitle').textContent = titles[page].subtitle;
    
    // Refresh charts when switching to home/analytics
    if (page === 'home') {
        refreshCharts();
    } else if (page === 'analytics') {
        updateAnalytics();
    }
}

// Load charts
async function loadCharts() {
    try {
        const response = await fetch('/api/analytics');
        const data = await response.json();
        
        // Score Distribution Chart
        const scoreCtx = document.getElementById('score-distribution-chart')?.getContext('2d');
        if (scoreCtx) {
            scoreChart = new Chart(scoreCtx, {
                type: 'line',
                data: {
                    labels: data.score_bins,
                    datasets: [{
                        label: 'Student Distribution',
                        data: data.score_distribution,
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    }
                }
            });
        }
        
        // Grade Distribution Chart
        const gradeCtx = document.getElementById('grade-distribution-chart')?.getContext('2d');
        if (gradeCtx) {
            gradeChart = new Chart(gradeCtx, {
                type: 'doughnut',
                data: {
                    labels: data.grade_labels,
                    datasets: [{
                        data: data.grade_distribution,
                        backgroundColor: ['#27ae60', '#3498db', '#f39c12', '#e67e22', '#e74c3c']
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
        }
        
        // Feature Importance Chart
        const featureCtx = document.getElementById('feature-importance-chart')?.getContext('2d');
        if (featureCtx) {
            featureChart = new Chart(featureCtx, {
                type: 'bar',
                data: {
                    labels: data.feature_names,
                    datasets: [{
                        label: 'Importance Score',
                        data: data.feature_importance,
                        backgroundColor: '#667eea'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    indexAxis: 'y',
                    plugins: {
                        legend: { position: 'top' }
                    }
                }
            });
        }
    } catch (error) {
        console.error('Error loading charts:', error);
    }
}

// Refresh charts
function refreshCharts() {
    if (scoreChart) scoreChart.destroy();
    if (gradeChart) gradeChart.destroy();
    if (featureChart) featureChart.destroy();
    loadCharts();
}

// Form handlers
function setupFormHandlers() {
    // Range sliders
    document.querySelectorAll('input[type="range"]').forEach(slider => {
        const output = slider.parentElement.querySelector('.range-value');
        if (output) {
            slider.addEventListener('input', function() {
                let unit = '';
                if (this.name.includes('hours')) unit = ' hours';
                if (this.name.includes('score')) unit = '';
                if (this.name.includes('attendance')) unit = '%';
                output.textContent = this.value + unit;
            });
        }
    });
    
    // Failure buttons
    document.querySelectorAll('.failure-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const value = this.dataset.value;
            const hiddenInput = this.closest('.form-group').querySelector('input[type="hidden"]');
            if (hiddenInput) hiddenInput.value = value;
            
            // Update active state
            this.parentElement.querySelectorAll('.failure-btn').forEach(b => {
                b.classList.remove('active');
            });
            this.classList.add('active');
        });
    });
    
    // Prediction form
    const form = document.getElementById('predictionForm');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            
            const resultDiv = document.getElementById('predictionResult');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<div class="loading">Predicting... <i class="fas fa-spinner fa-spin"></i></div>';
            
            try {
                const response = await fetch('/api/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                
                if (result.success) {
                    const grade = getGrade(result.predicted_score);
                    const progressAngle = (result.predicted_score / 100) * 360;
                    resultDiv.innerHTML = `
                        <div class="result-card" style="border-top-color: ${grade.color}">
                            <i class="fas fa-chart-line"></i>
                            <h3>Prediction Result</h3>
                            <div class="score-circle">
                                <div class="score-progress" style="background: conic-gradient(${grade.color} 0deg, ${grade.color} ${progressAngle}deg, rgba(255,255,255,0.1) ${progressAngle}deg, rgba(255,255,255,0.1) 360deg)"></div>
                                <span class="score">${Math.round(result.predicted_score)}</span>
                                <span class="max-score">/100</span>
                            </div>
                            <div class="grade" style="background: ${grade.color}">Grade ${grade.letter}</div>
                            <p class="advice">${grade.advice}</p>
                            <button onclick="savePrediction(${result.predicted_score})" class="save-btn">
                                <i class="fas fa-save"></i> Save Prediction
                            </button>
                        </div>
                        <div class="recent-activity" id="recentActivity" style="display: none;">
                            <h4><i class="fas fa-history"></i> Recent Activity</h4>
                            <div class="activity-item">
                                <i class="fas fa-save"></i>
                                <div class="activity-content">
                                    <span class="activity-title">Prediction Saved</span>
                                    <span class="activity-detail">Score: ${Math.round(result.predicted_score)} | Grade: ${grade.letter}</span>
                                    <span class="activity-time">Just now</span>
                                </div>
                            </div>
                        </div>
                    `;
                } else {
                    resultDiv.innerHTML = `<div class="error">Error: ${result.error}</div>`;
                }
            } catch (error) {
                resultDiv.innerHTML = `<div class="error">Error making prediction</div>`;
            }
        });
    }
}

function getGrade(score) {
    if (score >= 90) return { letter: 'A', color: '#27ae60', advice: 'Excellent! Keep up the great work! 🎉' };
    if (score >= 80) return { letter: 'B', color: '#3498db', advice: 'Good job! Aim for that A! 📚' };
    if (score >= 70) return { letter: 'C', color: '#f39c12', advice: 'Decent score. More practice could help! 💪' };
    if (score >= 60) return { letter: 'D', color: '#e67e22', advice: 'Need improvement. Consider more study hours! 📖' };
    return { letter: 'F', color: '#e74c3c', advice: 'Significant improvement needed. Seek help! 🆘' };
}

// Analytics functions
async function updateAnalytics() {
    const feature = document.getElementById('analyticsFeature')?.value;
    if (!feature) return;
    
    try {
        const response = await fetch(`/api/feature-analysis?feature=${feature}`);
        const data = await response.json();
        
        const ctx = document.getElementById('featureVsScoreChart')?.getContext('2d');
        if (ctx) {
            if (analyticsChart) analyticsChart.destroy();
            
            analyticsChart = new Chart(ctx, {
                type: 'scatter',
                data: {
                    datasets: [{
                        label: `${feature.replace(/_/g, ' ')} vs Final Score`,
                        data: data.points,
                        backgroundColor: '#667eea',
                        pointRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: (context) => {
                                    return `${feature}: ${context.parsed.x}, Score: ${Math.round(context.parsed.y)}`;
                                }
                            }
                        }
                    },
                    scales: {
                        x: { title: { display: true, text: feature.replace(/_/g, ' ') } },
                        y: { title: { display: true, text: 'Final Score' }, min: 0, max: 100 }
                    }
                }
            });
        }
        
        // Update correlation matrix
        const correlationDiv = document.getElementById('correlationMatrix');
        if (correlationDiv && data.correlation) {
            correlationDiv.innerHTML = `
                <table class="correlation-table">
                    ${data.correlation.map(row => `
                        <tr>
                            ${row.map(cell => `<td style="background: rgba(102, 126, 234, ${Math.abs(cell) * 0.7})">${cell.toFixed(2)}</td>`).join('')}
                        </tr>
                    `).join('')}
                </table>
            `;
        }
    } catch (error) {
        console.error('Error updating analytics:', error);
    }
}

// Settings functions
function loadSettings() {
    // Theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);

    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const theme = this.dataset.theme;
            setTheme(theme);
            localStorage.setItem('theme', theme);
        });
    });

    // Color theme
    const savedColorTheme = localStorage.getItem('colorTheme') || 'default';
    setColorTheme(savedColorTheme);

    document.querySelectorAll('.color-theme-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const colorTheme = this.dataset.color;
            setColorTheme(colorTheme);
            localStorage.setItem('colorTheme', colorTheme);
        });
    });

    // Refresh interval
    const intervalSelect = document.getElementById('refreshInterval');
    if (intervalSelect) {
        const savedInterval = localStorage.getItem('refreshInterval') || '0';
        intervalSelect.value = savedInterval;
        intervalSelect.addEventListener('change', function() {
            const interval = parseInt(this.value);
            localStorage.setItem('refreshInterval', interval);
            startAutoRefresh(interval);
        });
    }
}

function setTheme(theme) {
    document.body.className = `${theme}-theme`;
    const toggleSwitch = document.querySelector('.toggle-switch');
    if (toggleSwitch) {
        toggleSwitch.setAttribute('data-theme', theme);
    }
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.theme === theme) {
            btn.classList.add('active');
        }
    });
}

function setColorTheme(colorTheme) {
    const dashboardContainer = document.querySelector('.dashboard-container');
    if (dashboardContainer) {
        // Remove existing theme classes
        dashboardContainer.classList.remove('theme-blue', 'theme-purple', 'theme-green', 'theme-orange', 'theme-pink');
        // Add new theme class if not default
        if (colorTheme !== 'default') {
            dashboardContainer.classList.add(`theme-${colorTheme}`);
        }
    }

    // Update active button
    document.querySelectorAll('.color-theme-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.color === colorTheme) {
            btn.classList.add('active');
        }
    });
}

function startAutoRefresh(seconds) {
    if (refreshInterval) clearInterval(refreshInterval);
    if (seconds > 0) {
        refreshInterval = setInterval(() => {
            if (currentPage === 'home') refreshCharts();
            if (currentPage === 'analytics') updateAnalytics();
        }, seconds * 1000);
    }
}

async function retrainModel() {
    const btn = document.querySelector('.retrain-btn');
    if (!btn) return;
    const originalContent = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Retraining...';

    try {
        const response = await fetch('/api/retrain', { method: 'POST' });
        const result = await response.json();

        if (result.success) {
            alert(result.message);
        } else {
            alert(`Retrain failed: ${result.error}`);
        }
    } catch (error) {
        alert('Retrain failed: ' + error.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalContent;
    }
}

function exportData(format) {
    // Create a temporary link to trigger download
    const link = document.createElement('a');
    link.href = `/api/export/${format}`;
    link.download = `student_performance_data.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function savePrediction(score) {
    const predictions = JSON.parse(localStorage.getItem('predictions') || '[]');
    const grade = getGrade(score);
    const now = new Date();

    predictions.push({
        score: score,
        grade: grade.letter,
        date: now.toISOString(),
        features: Object.fromEntries(new FormData(document.getElementById('predictionForm')).entries())
    });

    localStorage.setItem('predictions', JSON.stringify(predictions));

    // Show recent activity
    const activityDiv = document.getElementById('recentActivity');
    if (activityDiv) {
        activityDiv.style.display = 'block';
        activityDiv.classList.add('activity-show');
    }

    // Show success message
    showNotification('Prediction saved successfully!', 'success');
}

function refreshData() {
    refreshCharts();
    updateAnalytics();
}

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" class="notification-close">&times;</button>
    `;

    // Add to page
    document.body.appendChild(notification);

    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}