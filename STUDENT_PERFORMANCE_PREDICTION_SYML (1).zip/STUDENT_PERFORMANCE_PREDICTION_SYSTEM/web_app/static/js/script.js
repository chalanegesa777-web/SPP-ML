// Update range sliders in real-time
document.querySelectorAll('input[type="range"]').forEach(slider => {
    const output = document.getElementById(slider.id + '_value');
    
    if (output) {
        slider.addEventListener('input', function() {
            let unit = '';
            if (this.id.includes('hours')) unit = ' hours';
            if (this.id.includes('score')) unit = '';
            if (this.id.includes('attendance')) unit = '%';
            
            output.textContent = this.value + unit;
        });
    }
});

// Past failures buttons
const failureButtons = document.querySelectorAll('.failure-btn');
const failureInput = document.getElementById('past_failures');

failureButtons.forEach(btn => {
    btn.addEventListener('click', function() {
        const failures = this.dataset.failures;
        failureInput.value = failures;
        
        // Update active state
        failureButtons.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
    });
});

// Form submission animation
const form = document.getElementById('predictionForm');
if (form) {
    form.addEventListener('submit', function(e) {
        const submitBtn = document.querySelector('.predict-btn');
        submitBtn.innerHTML = '<span class="btn-icon">⏳</span> Predicting...';
        submitBtn.disabled = true;
    });
}

// Add smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Animate cards on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.card, .feature-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
});