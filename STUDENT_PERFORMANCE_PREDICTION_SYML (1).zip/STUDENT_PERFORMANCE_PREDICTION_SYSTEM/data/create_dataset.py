import pandas as pd
import numpy as np
import os

np.random.seed(42)

# Create dataset
n_students = 1000

data = {
    'study_hours_per_day': np.random.uniform(0.5, 10, n_students),
    'previous_score': np.random.uniform(30, 100, n_students),
    'attendance_percentage': np.random.uniform(40, 100, n_students),
    'sleep_hours_per_day': np.random.uniform(4, 9, n_students),
    'extracurricular_hours': np.random.uniform(0, 15, n_students),
    'family_income_level': np.random.choice(['Low', 'Medium', 'High'], n_students),
    'parental_education': np.random.choice(['No College', 'Some College', 'Bachelor', 'Master+'], n_students),
    'internet_access': np.random.choice(['Yes', 'No'], n_students, p=[0.85, 0.15]),
    'past_failures': np.random.choice([0, 1, 2, 3], n_students, p=[0.7, 0.15, 0.1, 0.05])
}

df = pd.DataFrame(data)

# Calculate final score
df['final_score'] = (
    0.3 * df['study_hours_per_day'] * 10 +
    0.4 * df['previous_score'] +
    0.15 * df['attendance_percentage'] +
    0.05 * df['sleep_hours_per_day'] * 10 -
    0.03 * df['extracurricular_hours'] * 5 -
    0.05 * df['past_failures'] * 10
) + np.random.normal(0, 5, n_students)

df['final_score'] = df['final_score'].clip(0, 100)

def get_grade(score):
    if score >= 90: 
        return 'A'
    elif score >= 80: 
        return 'B'
    elif score >= 70: 
        return 'C'
    elif score >= 60: 
        return 'D'
    else: 
        return 'F'

df['grade'] = df['final_score'].apply(get_grade)

# Save dataset in the current folder (data folder)
df.to_csv('student_data.csv', index=False)
print(f"✅ Dataset created successfully!")
print(f"📊 Created {len(df)} student records")
print(f"\n📋 First 3 rows:")
print(df.head(3))
print(f"\n📈 Grade distribution:")
print(df['grade'].value_counts())
print(f"\n📁 File saved to: {os.getcwd()}\\student_data.csv")