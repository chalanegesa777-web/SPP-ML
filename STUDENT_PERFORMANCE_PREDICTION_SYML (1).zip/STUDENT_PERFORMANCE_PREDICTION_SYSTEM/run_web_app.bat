@echo off
echo Starting Student Performance Predictor Web Application...
echo.
cd web_app
python app.py
pause