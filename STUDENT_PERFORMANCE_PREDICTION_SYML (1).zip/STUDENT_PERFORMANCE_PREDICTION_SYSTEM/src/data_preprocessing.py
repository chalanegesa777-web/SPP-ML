import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib
import os

def load_and_preprocess_data(filepath='../data/student_data.csv'):
    """Load data and perform preprocessing"""
    
    # Get the absolute path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, '..', 'data', 'student_data.csv')
    
    df = pd.read_csv(data_path)
    print(f"[OK] Loaded {len(df)} records from {data_path}")
    
    # Encode categorical variables
    label_encoders = {}
    categorical_cols = ['family_income_level', 'parental_education', 'internet_access']
    
    for col in categorical_cols:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        label_encoders[col] = le
    
    # Define features and target
    feature_cols = ['study_hours_per_day', 'previous_score', 'attendance_percentage',
                    'sleep_hours_per_day', 'extracurricular_hours', 'family_income_level',
                    'parental_education', 'internet_access', 'past_failures']
    
    X = df[feature_cols]
    y = df['final_score']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Save preprocessing objects
    os.makedirs('../models', exist_ok=True)
    joblib.dump(scaler, '../models/scaler.pkl')
    joblib.dump(label_encoders, '../models/label_encoders.pkl')
    joblib.dump(feature_cols, '../models/feature_cols.pkl')
    
    print(f"[OK] Training set size: {X_train_scaled.shape[0]} records")
    print(f"[OK] Test set size: {X_test_scaled.shape[0]} records")
    
    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, label_encoders, feature_cols

if __name__ == "__main__":
    load_and_preprocess_data()