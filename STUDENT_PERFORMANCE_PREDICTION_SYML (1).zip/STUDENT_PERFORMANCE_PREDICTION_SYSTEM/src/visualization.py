import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class Visualizer:
    def __init__(self):
        self.df = pd.read_csv('../data/student_data.csv')
        
    def plot_score_distribution(self, parent_frame):
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.histplot(self.df['final_score'], bins=20, kde=True, ax=ax, color='skyblue')
        ax.set_title('Distribution of Student Final Scores', fontsize=14, fontweight='bold')
        ax.set_xlabel('Final Score')
        ax.set_ylabel('Number of Students')
        ax.axvline(self.df['final_score'].mean(), color='red', linestyle='--', 
                   label=f'Mean: {self.df["final_score"].mean():.1f}')
        ax.legend()
        
        canvas = FigureCanvasTkAgg(fig, parent_frame)
        canvas.draw()
        return canvas.get_tk_widget()
    
    def plot_grade_distribution(self, parent_frame):
        fig, ax = plt.subplots(figsize=(8, 5))
        grade_counts = self.df['grade'].value_counts()
        colors = ['#2ecc71', '#3498db', '#f39c12', '#e74c3c', '#95a5a6']
        ax.pie(grade_counts, labels=grade_counts.index, autopct='%1.1f%%', colors=colors[:len(grade_counts)])
        ax.set_title('Grade Distribution', fontsize=14, fontweight='bold')
        
        canvas = FigureCanvasTkAgg(fig, parent_frame)
        canvas.draw()
        return canvas.get_tk_widget()
    
    def plot_correlation_heatmap(self, parent_frame):
        fig, ax = plt.subplots(figsize=(10, 8))
        numerical_cols = ['study_hours_per_day', 'previous_score', 'attendance_percentage',
                         'sleep_hours_per_day', 'extracurricular_hours', 'past_failures', 'final_score']
        corr_matrix = self.df[numerical_cols].corr()
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, fmt='.2f', square=True, ax=ax)
        ax.set_title('Feature Correlation Heatmap', fontsize=14, fontweight='bold')
        
        canvas = FigureCanvasTkAgg(fig, parent_frame)
        canvas.draw()
        return canvas.get_tk_widget()