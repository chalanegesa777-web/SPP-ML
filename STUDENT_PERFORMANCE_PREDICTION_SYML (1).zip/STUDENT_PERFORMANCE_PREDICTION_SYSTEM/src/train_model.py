import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import matplotlib.pyplot as plt
from data_preprocessing import load_and_preprocess_data
import os

def train_and_evaluate_models():
    """Train multiple models and select the best one"""
    
    X_train, X_test, y_train, y_test, scaler, label_encoders, feature_cols = load_and_preprocess_data()
    
    # Define models
    models = {
        'Linear Regression': LinearRegression(),
        'Ridge Regression': Ridge(alpha=1.0),
        'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
        'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42)
    }
    
    results = {}
    best_model = None
    best_score = -np.inf
    
    print("\n" + "="*60)
    print("MODEL TRAINING AND EVALUATION")
    print("="*60)
    
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        
        print(f"\n{name}:")
        print(f"  MAE:  {mae:.2f}")
        print(f"  RMSE: {rmse:.2f}")
        print(f"  R2:   {r2:.4f}")
        
        if r2 > best_score:
            best_score = r2
            best_model = model
    
    # Save best model
    os.makedirs('../models', exist_ok=True)
    joblib.dump(best_model, '../models/performance_model.pkl')
    print(f"\n[OK] Best model saved: {best_model.__class__.__name__} (R2 = {best_score:.4f})")
    
    # Plot feature importance if available
    if hasattr(best_model, 'feature_importances_'):
        plt.figure(figsize=(10, 6))
        importances = best_model.feature_importances_
        indices = np.argsort(importances)[::-1]
        
        plt.bar(range(len(importances)), importances[indices])
        plt.xticks(range(len(importances)), [feature_cols[i] for i in indices], rotation=45, ha='right')
        plt.title('Feature Importance')
        plt.tight_layout()
        plt.savefig('../models/feature_importance.png')
        print(f"[OK] Feature importance chart saved to 'models/feature_importance.png'")
        plt.show()
    
    return best_model

if __name__ == "__main__":
    train_and_evaluate_models()